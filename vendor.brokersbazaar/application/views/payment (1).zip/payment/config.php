<?php

$keyId = 'rzp_test_6IzwO3wyFhcPpr';
$keySecret = 's5VerPfSzdIY6PDxU8odP3Xe';
$displayCurrency = '<Enter your display currency here>';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
