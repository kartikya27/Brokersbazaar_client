


<div class="container px-1 py-5 mx-auto">
    <div class="row d-flex justify-content-center">
        <div class="col-xl-4 col-lg-4 col-md-4 col-12 text-center" style="margin:auto;">
        
      <h2 style="text-align: left;">  Grow your business.
          <br>
          Sell on BrokarBazar.<br>
Give a kickstart to your business.<br><br>
Register Now<br><br>
It's quick and easy.
        </h2>
        
        
        
        </div>
        <div class="col-xl-8 col-lg-8 col-md-8 col-12 text-center">
          
           
            <div class="card">
                 <?php
            
            echo $this->session->userdata('email');
             echo $this->session->userdata('user');
                
            ?>
<!--        <label class="form-control-label px-3">-->

                <h5 class="text-center mb-4">Vendor Company Details</h5>
                <form class="form-card" action="#" method="post">
                    <div class="row justify-content-between text-left">
                       
                        
                        <div class="form-group col-sm-6 flex-column d-flex">  <label class="sr-only" for="">License no.</label>
                             <input type="text" name="license" class="md-input form-control" id="cofounder3" placeholder="License no."> </div>
                        
                        <div class="form-group col-sm-6 flex-column d-flex">  <label class="sr-only" for="">GST</label>
                <input type="text" name="gst" class="md-input form-control" id="cofounder3" placeholder="GST no."> </div>
                        
                    </div>
                    <div class="row justify-content-between text-left">
                        <div class="form-group col-sm-6 flex-column d-flex">  <label class="sr-only" for="">Brokerage Commission</label>
                <input type="text" name="brokerage_commission" class="md-input form-control" id="cofounder3" placeholder="Brokerage Commission">
                        </div>
                    <div class="form-group col-sm-6 flex-column d-flex">  <label class="sr-only" for="">Equity SEBI Registration No</label>
                <input type="text" name="Equity_SEBI_Registration_No" class="md-input form-control" id="cofounder3" placeholder="Equity SEBI Registration No"> </div>
                    </div>
                    <div class="row justify-content-between text-left">
                        <div class="form-group col-sm-6 flex-column d-flex">  <label class="sr-only" for="">Exchange Registration Nos</label>
                <input type="text" name="Exchange_Registration_Nos" class="md-input form-control" id="cofounder3" placeholder="Exchange Registration Nos"> </div>
                   
                     <div class="form-group col-sm-6 flex-column d-flex"> 
                       <label class="sr-only" for="">NSE TM Code</label>
                <input type="text" name="brokerage_commission" class="md-input form-control" id="cofounder3" placeholder="NSE TM Code"></div>
                    
                    
                    </div>
                    
                    <div class="row justify-content-between text-left">
                        
                        <div class="form-group col-6 flex-column d-flex">   <label class="sr-only" for="">Clearing No</label>
                <input type="text" name="NSE_TM_Code" class="md-input form-control" id="cofounder3" placeholder="Clearing No"> </div>
                   
                     <div class="form-group col-6 flex-column d-flex">    <label class="sr-only" for="">BSE Clearing No</label>
                <input type="text" name="BSE_Clearing_No" class="md-input form-control" id="cofounder3" placeholder="BSE Clearing No"> </div>
                    
                    
                    </div>
                    
                    
                    
                 <div class="row justify-content-between text-left">
                        
                        <div class="form-group col-6 flex-column d-flex">   <label class="sr-only" for="">MSEI TM Code</label>
                <input type="text" name="MSEI_TM_Code" class="md-input form-control" id="cofounder3" placeholder="MSEI TM Code"> </div>
                   
                     <div class="form-group col-6 flex-column d-flex">    <label class="sr-only" for="">Clearing No</label>
                <input type="text" name="Clearing_No" class="md-input form-control" id="cofounder3" placeholder="Clearing No"> </div>
                    
                    
                    </div>
                    
                      <div class="row justify-content-between text-left">
                        
                        <div class="form-group col-6 flex-column d-flex">    <label class="sr-only" for="">MCX TM No</label>
                <input type="text" name="MCX_TM_No" class="md-input form-control" id="cofounder3" placeholder="MCX TM No"></div>
                   
                     <div class="form-group col-6 flex-column d-flex">     <label class="sr-only" for="">Clearing No</label>
                <input type="text" name="Clearing_No" class="md-input form-control" id="cofounder3" placeholder="Clearing No"> </div>
                    
                    
                    </div>
                    
                      <div class="row justify-content-between text-left">
                        
                        <div class="form-group col-6 flex-column d-flex">   <label class="sr-only" for="">NCDEX TM No</label>
                <input type="text" name="NCDEX_TM_No" class="md-input form-control" id="cofounder3" placeholder="NCDEX TM No"></div>
                   
                     <div class="form-group col-6 flex-column d-flex">    <label class="sr-only" for="">Clearing No</label>
                <input type="text" name="Clearing_No" class="md-input form-control" id="cofounder3" placeholder="Clearing No"> </div>
                    
                    
                    </div>
                    
                    
                    
                          <div class="row justify-content-between text-left">
                        
                        <div class="form-group col-6 flex-column d-flex">  <label class="sr-only" for="">ICEX TM ID</label>
                <input type="text" name="ICEX_TM_ID" class="md-input form-control" id="cofounder3" placeholder="ICEX TM ID"></div>
                   
                     <div class="form-group col-6 flex-column d-flex">     <label class="sr-only" for="">SEBI Registration for DP</label>
                <input type="text" name="SEBI_Registration_for_DP" class="md-input form-control" id="cofounder3" placeholder="SEBI Registration for DP"> </div>
                    
                    
                    </div>
                    
                          <div class="row justify-content-between text-left">
                        
                        <div class="form-group col-6 flex-column d-flex">   <label class="sr-only" for="">NSDL- DP ID</label>
                <input type="text" name="NSDL_DP_ID" class="md-input form-control" id="cofounder3" placeholder="NSDL- DP ID"></div>
                   
                     <div class="form-group col-6 flex-column d-flex">    <label class="sr-only" for="">CDSL DP ID</label>
                <input type="text" name="CDSL_DP_ID" class="md-input form-control" id="cofounder3" placeholder="CDSL DP ID"> </div>
                    
                    
                    </div>
                    
                          <div class="row justify-content-between text-left">
                        
                        <div class="form-group col-12 flex-column d-flex">  <label class="sr-only" for="">SEBI Research Analysts Registration No</label>
                <input type="text" name="SEBI_Research_Analysts_Registration_No" class="md-input form-control" id="cofounder3" placeholder="SEBI Research Analysts Registration No"></div>
                   
                    
                    </div>
                    
                     <div class="row justify-content-between text-left">
                         
                     <div class="form-group col-6 flex-column d-flex">   <label class="sr-only" for="">SEBI PMS Registration No</label>
                <input type="text" name="SEBI_PMS_Registration_No" class="md-input form-control" id="cofounder3" placeholder="SEBI PMS Registration No"> </div>
                     
                    <div class="form-group col-6 flex-column d-flex"> 
                      <label class="sr-only" for="">CMBPID NCL CM</label>
                <input type="text" name="CMBPID_NCL_CM" class="md-input form-control" id="cofounder3" placeholder="CMBPID NCL CM">
                         </div>
                    
                    </div>
                    
                    
                    
                    
                    <div class="row justify-content-end">
                        <div class="form-group col-sm-6"> <button type="submit" name="submitVendor" class="btn-block btn-primary">Next</button> </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>

<Script>

function validate(val) {
v1 = document.getElementById("fname");
v2 = document.getElementById("lname");
v3 = document.getElementById("email");
v4 = document.getElementById("mob");
v5 = document.getElementById("job");
v6 = document.getElementById("ans");

flag1 = true;
flag2 = true;
flag3 = true;
flag4 = true;
flag5 = true;
flag6 = true;

if(val>=1 || val==0) {
if(v1.value == "") {
v1.style.borderColor = "red";
flag1 = false;
}
else {
v1.style.borderColor = "green";
flag1 = true;
}
}

if(val>=2 || val==0) {
if(v2.value == "") {
v2.style.borderColor = "red";
flag2 = false;
}
else {
v2.style.borderColor = "green";
flag2 = true;
}
}
if(val>=3 || val==0) {
if(v3.value == "") {
v3.style.borderColor = "red";
flag3 = false;
}
else {
v3.style.borderColor = "green";
flag3 = true;
}
}
if(val>=4 || val==0) {
if(v4.value == "") {
v4.style.borderColor = "red";
flag4 = false;
}
else {
v4.style.borderColor = "green";
flag4 = true;
}
}
if(val>=5 || val==0) {
if(v5.value == "") {
v5.style.borderColor = "red";
flag5 = false;
}
else {
v5.style.borderColor = "green";
flag5 = true;
}
}
if(val>=6 || val==0) {
if(v6.value == "") {
v6.style.borderColor = "red";
flag6 = false;
}
else {
v6.style.borderColor = "green";
flag6 = true;
}
}

flag = flag1 && flag2 && flag3 && flag4 && flag5 && flag6;

return flag;
}


</Script>
