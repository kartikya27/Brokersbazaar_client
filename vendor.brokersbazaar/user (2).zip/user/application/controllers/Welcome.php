<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
        $this->load->view('include/header');
		$this->load->view('home');
	}
    
      public function registration()
      {
        $this->load->model('home');
       $this->load->helper('url');
		
        $data['name']=$this->input->post('name');
        $data['email']=$this->input->post('email');
        $data['Address']=$this->input->post('Address');
        $data['city']=$this->input->post('city');
        $data['state']=$this->input->post('state');
        $data['pin']=$this->input->post('pin');
          $data['company_name']=$this->input->post('company_name');
          $data['phone']=$this->input->post('mob');
          $data['uniqueID'] = uniqid();
        
        $this->home->registration($data);
	}
    
    
    public function details()
	{
        $this->load->model('home');
        $this->load->view('include/header');
       
		$this->load->view('details');
        echo $this->session->userdata('email');
         echo $this->session->userdata('user');
	}
    
    
    
    
}




