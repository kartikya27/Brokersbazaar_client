<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Model {

        public function registration($data){
      
            $this->db->insert('vendor',$data);
            $this->session->set_userdata('email','hello');
            $this->session->set_userdata('user',$data['uniqueID']);
            redirect(base_url().'details?user='.$data['uniqueID']);
            
}

    
    
    
    



}
?>