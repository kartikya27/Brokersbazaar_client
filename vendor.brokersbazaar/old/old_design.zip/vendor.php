<head>

<link rel="stylesheet" href="http://galiyaraa.in/en-IN/assets/css/master.css">
<!-- Responsive Style Sheets -->
<link rel="stylesheet" href="http://galiyaraa.in/en-IN/assets/css/responsive.css">



<section class="white-bg transition-none" style="padding-top:0px;">
    <div class="container">
  <form name="contact-form" id="contact-form-03" action="send.php" method="POST" class="contact-form-style-03 mt-50">
      <div class="row">
          <h2 class="font-700">Vendor Registration Page</h2>
          <hr class="left-line dark-bg">
          <p>Dummy Text Dummy Text Dummy Text Dummy Text Dummy Text </p>
        <div class="col-md-4 col-sm-4 col-xs-12 xs-mb-30">
          <p><b><u>Personal Information</u></b></p>
      
            <div class="messages"></div>
              <div class="form-group">
                <label class="" for="">Full Name </label>
                <input type="text" name="name" class="md-input" id="cofounder3" placeholder="Name">
                <div class="help-block with-errors"></div>
              </div>
            
            <div class="form-group">
                <label class="sr-only" for="email">Email</label>
                <input type="email" name="email" class="md-input" id="email3" placeholder="Email*" required data-error="Please Enter Valid Email">
                <div class="help-block with-errors"></div>
              </div>
            
             <div class="form-group">
                <label class="" for="">Company name</label>
                <input type="text" name="company_name" class="md-input" id="cofounder3" placeholder="Company Name">
                <div class="help-block with-errors"></div>
              </div>
              <div class="form-group">
                <label class="" for="">Address</label>
                <input type="text" name="Address" class="md-input" id="cofounder3" placeholder="Address">
                <div class="help-block with-errors"></div>
              </div>
            
             <div class="form-group">
                <label class="" for="">City</label>
                <input type="text" name="city" class="md-input" id="cofounder3" placeholder="City">
                <div class="help-block with-errors"></div>
              </div>
            
             <div class="form-group">
                <label class="" for="">PIN</label>
                <input type="text" name="pin" class="md-input" id="cofounder3" placeholder="Pin">
                <div class="help-block with-errors"></div>
              </div>
            
            <div class="form-group">
                <label class="" for="">State</label>
                <input type="text" name="state" class="md-input" id="cofounder3" placeholder="State">
                <div class="help-block with-errors"></div>
              </div>
          
            <div class="form-group">
                <label class="" for="">License no.</label>
                <input type="text" name="license" class="md-input" id="cofounder3" placeholder="License no.">
                <div class="help-block with-errors"></div>
              </div>
            
             <div class="form-group">
                <label class="" for="">GST</label>
                <input type="text" name="gst" class="md-input" id="cofounder3" placeholder="GST no.">
                <div class="help-block with-errors"></div>
              </div>
            
             <div class="form-group">
                <label class="" for="">Brokerage Commission</label>
                <input type="text" name="brokerage_commission" class="md-input" id="cofounder3" placeholder="Brokerage Commission">
                <div class="help-block with-errors"></div>
              </div>
            
            
            
          </div>
            <div class="col-md-4 col-sm-4 col-xs-12 xs-mb-30">
            
            
             <!---new field--->
                
             
                
                
               
             
             
             
        </div>
          <div class="col-md-4 col-sm-4 col-xs-12 xs-mb-30">  
         
          
           <button type="submit" name="vendorSubmit" class="btn btn-dark btn-md remove-margin btn-square">Send</button>
          
      </div>
          
          
      </div>
                
              </form>
    </div>
  </section>