<head>

<link rel="stylesheet" href="http://galiyaraa.in/en-IN/assets/css/master.css">
<!-- Responsive Style Sheets -->
<link rel="stylesheet" href="http://galiyaraa.in/en-IN/assets/css/responsive.css">
</head>


<section class="white-bg transition-none" style="padding-top:0px;">
    <div class="container">
  <form name="contact-form" id="contact-form-03" action="send.php" method="POST" class="contact-form-style-03 mt-50">
      <div class="row">
          <h2 class="font-700">Dummy Text</h2>
          <hr class="left-line dark-bg">
          <p>Dummy Text Dummy Text Dummy Text Dummy Text Dummy Text <a href="vendor.php">Vendor Page</a> </p>
        <div class="col-md-6 col-sm-6 col-xs-12 xs-mb-30">
          <p><b><u>Personal Information</u></b></p>
      
            <div class="messages"></div>
              <div class="form-group">
                <label class="" for="">Full Name </label>
                <input type="text" name="name" class="md-input" id="cofounder3" placeholder="Name">
                <div class="help-block with-errors"></div>
              </div>
             
              <div class="form-group">
                <label class="sr-only" for="email">Email</label>
                <input type="email" name="email" class="md-input" id="email3" placeholder="Email*" required data-error="Please Enter Valid Email">
                <div class="help-block with-errors"></div>
              </div>
               <div class="form-group">
                <label class="sr-only" for="phone">Mobile</label>
                <input type="text" name="mobile" class="md-input" id="Mobile3" placeholder="Mobile*" required data-error="Please Enter Valid mobile">
                <div class="help-block with-errors"></div>
              </div>
             
              <div class="form-group">
                <label class="sr-only" for="message">Your Message </label>
                <textarea name="message" class="md-textarea" id="message3" rows="7" placeholder="message" required data-error="Please, Provide Product Summery"></textarea>
          
              </div>
              <button type="submit" name="submit" class="btn btn-dark btn-md remove-margin btn-square">Send</button>
        </div>
            
      </div>
                
              </form>
    </div>
  </section>